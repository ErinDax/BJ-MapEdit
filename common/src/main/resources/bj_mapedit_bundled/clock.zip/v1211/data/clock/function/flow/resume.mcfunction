# 恢复原生时间流逝（1.21.9 – 1.21.11）
gamerule advance_time true
scoreboard players set #speed clock.data 1
scoreboard players set #slowdiv clock.data 1
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"时间流逝已恢复（1 倍速）","color":"gray"}]
