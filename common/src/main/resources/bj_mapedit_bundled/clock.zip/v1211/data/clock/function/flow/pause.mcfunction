# 冻结时间（1.21.9 – 1.21.11：gamerule advance_time）
gamerule advance_time false
scoreboard players set #speed clock.data 0
scoreboard players set #slowdiv clock.data 1
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"时间流逝已暂停","color":"gray"}]
