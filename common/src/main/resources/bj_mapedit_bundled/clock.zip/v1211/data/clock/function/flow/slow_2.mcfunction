# 0.5 倍速（原速的 1/2）：关掉原版推进，每 2 tick 只推进 1 tick
gamerule advance_time false
scoreboard players set #speed clock.data 1
scoreboard players set #slowdiv clock.data 2
scoreboard players set #stag clock.data 0
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"时间流逝 0.5 倍速（原速的 1/2）","color":"gray"}]
