# ============================================================
#  clock:boot —— 1.21.9 – 1.21.11 覆盖版
#  差异：gamerule doDaylightCycle 已改名为 advance_time
# ============================================================
gamerule advance_time true
scoreboard players set #speed clock.data 1

tag @a[tag=!clock.off] add clock.on

scoreboard players set #boot clock.data 1
