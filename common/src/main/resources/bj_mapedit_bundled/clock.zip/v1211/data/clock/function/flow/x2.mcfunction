# 2 倍速流逝（1.21.9 – 1.21.11：关原版推进，数据包自己 time add）
gamerule advance_time false
scoreboard players set #speed clock.data 2
scoreboard players set #slowdiv clock.data 1
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"时间流逝 2 倍速","color":"gray"}]
