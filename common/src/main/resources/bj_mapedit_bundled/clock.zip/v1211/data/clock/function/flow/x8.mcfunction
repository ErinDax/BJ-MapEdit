# 8 倍速流逝（1.21.9 – 1.21.11）
gamerule advance_time false
scoreboard players set #speed clock.data 8
scoreboard players set #slowdiv clock.data 1
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"时间流逝 8 倍速","color":"gray"}]
