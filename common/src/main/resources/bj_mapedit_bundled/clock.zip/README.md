# 快捷时间显示 · 通用模板 v1.3

> 一个数据包，同时支持 **1.20.1 → 26.3**。
> 屏幕 actionbar 显示 `第N天  时:分  时段`，三个元素的**顺序与显隐都可自由调**，天数可指定从第 N 天开始，
> 时间流逝可暂停、可加速（2/4/8 倍）、也可**慢放（1/2、1/4、1/8 速）**。

---

## 一、装上去就能用

把整个文件夹（或 zip）丢进：

```
存档目录/saves/<世界名>/datapacks/
专用服务器/world/datapacks/
```

进游戏后玩家 actionbar 立刻出现：

```
第3天  06:30  清晨
```

无需任何配置。

> **zip 必须满足**：`pack.mcmeta` 在压缩包最外层。
> 如果你的压缩软件包了一层文件夹（`快捷时间显示/pack.mcmeta`），游戏读不到这个包 —— 压缩时要**进入文件夹内部全选**再压。

---

## 二、显示布局

三个元素：**天数**（第N天）、**时间**（时:分）、**时段**（清晨/上午/…）

### 2.1 改顺序（三元素全显时生效）

| 指令 | 显示效果 |
|---|---|
| `/function clock:cfg/order_1` | 第3天  06:30  清晨 ←**默认** |
| `/function clock:cfg/order_2` | 第3天  清晨  06:30 |
| `/function clock:cfg/order_3` | 06:30  第3天  清晨 |
| `/function clock:cfg/order_4` | 06:30  清晨  第3天 |
| `/function clock:cfg/order_5` | 清晨  第3天  06:30 |
| `/function clock:cfg/order_6` | 清晨  06:30  第3天 |

### 2.2 单个元素显隐

| 指令 | 作用 |
|---|---|
| `/function clock:cfg/show_day` / `hide_day` | 显示 / 隐藏「第N天」 |
| `/function clock:cfg/show_time` / `hide_time` | 显示 / 隐藏「时:分」 |
| `/function clock:cfg/show_seg` / `hide_seg` | 显示 / 隐藏「时段」 |

显隐与顺序可自由组合，例如：

```
/function clock:cfg/order_4      → 06:30  清晨  第3天
/function clock:cfg/hide_day     → 06:30  清晨        （天数去掉，其余按 order_4 的相对次序）
/function clock:cfg/hide_seg     → 06:30  第3天
/function clock:cfg/show_day     → 恢复显示天数
```

### 2.3 布局号对照（调试 / 手改用）

三种元素的所有「非空有序组合」共 15 种，内部用布局号 1–15 表示：

| # | 布局 | # | 布局 | # | 布局 |
|---|---|---|---|---|---|
| 1 | 天 时 段 | 6 | 段 时 天 | 11 | 时 段 |
| 2 | 天 段 时 | 7 | 天 时 | 12 | 段 时 |
| 3 | 时 天 段 | 8 | 时 天 | 13 | 天 |
| 4 | 时 段 天 | 9 | 天 段 | 14 | 时 |
| 5 | 段 天 时 | 10 | 段 天 | 15 | 段 |

随时查看当前设置：`/function clock:cfg/help`（会同时报出当前 `排序号` 与 `布局号`）。

想直接指定布局号：`/scoreboard players set #layout clock.data 5` → 变「段 天 时」（下一次刷新生效）。
注意：之后任何一次 `cfg/order_*`、`cfg/show_*`、`cfg/hide_*` 都会重新按规则算回布局号。

### 2.4 天数调整（从第 N 天开始）

显示的天数 = **真实世界天数**（`gametime/24000+1`）+ **偏移量 `#dayoff`**。
既能跟世界年龄一致，也能强行指定剧情天数。

| 指令 | 作用 |
|---|---|
| `/function clock:day/set_1` … `set_10` | 让显示变成「第 1 天」…「第 10 天」←开局摆剧情用这个 |
| `/scoreboard players set #daytar clock.data N` → `/function clock:day/to` | 任意天数（可以大于 10，也可以比真实天数小） |
| `/function clock:day/add` / `sub` | 显示天数 +1 / -1（剧情推进一天，不动真实时间） |
| `/function clock:day/reset` | 清掉偏移，回到真实世界天数 |
| `/function clock:nextday` | 时刻跳到次日 06:00 **且显示天数 +1** |

要点：

- `set_*` 与 `to` 内部自动算偏移（目标天数 − 真实天数），不是把天数写死
- 偏移存在 `#dayoff`，**不会被刷新覆盖**（每 5 tick 只重算真实天数，再叠加偏移）
- 想让地图从第 7 天开始：进世界后跑一次 `/function clock:day/set_7`，之后正常流逝会自动往上加
- 想看「真实天数」是多少：`/scoreboard players get #dayraw clock.data`

---

## 三、玩家用法（无需 OP）

| 指令 | 作用 |
|---|---|
| `/trigger clock.hud set 1` | 自己开启时间显示 |
| `/trigger clock.hud set 2` | 自己关闭时间显示 |

关闭状态会被记住，换世界不重置。

---

## 四、GM / 地图作者指令（需 OP，权限等级 2）

### 显示
| 指令 | 作用 |
|---|---|
| `/function clock:hud/on` | 全服开启 HUD |
| `/function clock:hud/off` | 全服关闭 HUD |
| `/function clock:hud/update` | 立刻刷新一次（不等 0.25 秒） |

### 时间流逝
| 指令 | 效果 |
|---|---|
| `/function clock:flow/pause` | 冻结时间（昼夜停在当前时刻） |
| `/function clock:flow/resume` | 恢复原生流逝（1 倍速） |
| `/function clock:flow/x2` `x4` `x8` | 2 / 4 / 8 倍速 |
| `/function clock:flow/slow_2` | **0.5 倍速**（原速的 1/2，每 2 tick 推进 1 tick） |
| `/function clock:flow/slow_4` | **0.25 倍速**（1/4，每 4 tick 推进 1 tick） |
| `/function clock:flow/slow_8` | **0.125 倍速**（1/8，每 8 tick 推进 1 tick） |

实测（空服务端各跑 5 秒，读 `daytime` 增量）：1 倍速 +100 → 1/2 速 +50 → 1/4 速 +25 → 4 倍速 +400；暂停 3 秒增量为 0。

> 快进与慢放都靠「关原版推进 + 数据包自己 `time add`」：
> 加速是每 tick `add N`；慢放是每 `N` tick 才 `add 1`（`#stag % #slowdiv == 0` 时触发）。
> 好处是暂停/变速语义在所有 MC 版本上完全一致；代价是变速期间**睡觉跳过夜晚不再生效**（正常玩法用 resume 即可）。
> 三个 slow_* 与 x2/x4/x8、pause、resume 互相切换时会自动清掉对方档位，不会「又慢又加速」。

### 定点与跳天
| 指令 | 时刻 |
|---|---|
| `/function clock:set/dawn` | 06:00 |
| `/function clock:set/morning` | 09:00 |
| `/function clock:set/noon` | 12:00 |
| `/function clock:set/afternoon` | 15:00 |
| `/function clock:set/dusk` | 18:00 |
| `/function clock:set/night` | 21:00 |
| `/function clock:set/midnight` | 00:00 |
| `/function clock:set/predawn` | 03:00 |
| `/function clock:nextday` | 次日 06:00 + 天数 +1（轮回 / 剧情地图常用） |

### 查询
| 指令 | 作用 |
|---|---|
| `/function clock:status` | 向自己报告当前时刻、天数、流逝速度（慢放时额外报「原速的 1/N」） |
| `/function clock:help` | 聊天栏打印主要指令表 |
| `/function clock:cfg/help` | 聊天栏打印布局设置表 |

---

## 五、目录结构与「为什么要 4 套」

数据包 overlay 只能**整目录替换**（新版目录名从 `functions/` 变成 `function/`，旧目录在新版本里直接被忽略），所以每个语法世代必须存一份完整副本：

```
pack.mcmeta            ← 版本分段声明
data/                  ← 1.20.1 – 1.20.4
v121/data/             ← 1.20.5 – 1.21.8
v1211/data/            ← 1.21.9 – 1.21.11
v26/data/              ← 26.1 – 26.3+
```

四套的内容**只有两处不同**（其余完全一致）：

| 差异 | 1.20.1 – 1.21.8 | 1.21.9 – 1.21.11 | 26.1+ |
|---|---|---|---|
| 读当前时刻（`hud/calc` 第 1 条） | `time query daytime` | `time query daytime` | `time query time` |
| 开关时间流逝（`boot`、`flow/*`） | `gamerule doDaylightCycle` | `gamerule advance_time` | `gamerule advance_time` |

> 26.x 重构了时间系统（world clock + timeline），`daytime` 已不存在、gamerule 全部改成 snake_case
> （`doDaylightCycle` → `advance_time`），所以必须分开。

**改逻辑时**：功能类文件（`hud/*`、`cfg/*`、`day/*`、`set/*`、`status`、`help`、`tick`）四套内容相同 → 改完一套复制到另外三套；
两个差异点（`hud/calc` 首行、`boot` 与 `flow/*` 的 gamerule 名）各版本保持原样，别统一。

---

## 六、计分板与假玩家（调试用）

| 计分板 | 用途 |
|---|---|
| `clock.data` | 全部数值（dummy） |
| `clock.hud` | 玩家自助开关（trigger） |

| 假玩家 | 含义 |
|---|---|
| `#t` | 当前 clock tick（0 = 06:00，24000/天） |
| `#h` / `#m` | 小时 / 分钟 |
| `#h10` `#h1` `#m10` `#m1` | 十位 / 个位（补前导零） |
| `#dayraw` | **真实**世界天数 = gametime/24000 + 1 |
| `#dayoff` | 天数偏移（由 `clock:day/*` 调整） |
| `#day` | **显示**天数 = `#dayraw` + `#dayoff` |
| `#daytar` | 「设为第 N 天」的目标值（配合 `clock:day/to`） |
| `#ord` | 排序号 1–6 |
| `#showd` `#showt` `#shows` | 天数 / 时间 / 时段的显隐（1 显示、0 隐藏） |
| `#cnt` | 当前可见元素个数（由 layout 计算） |
| `#layout` | 最终布局号 1–15 |
| `#speed` | 0 冻结 / 1 原生或慢速 / 2·4·8 加速 |
| `#slowdiv` | 1 不慢放；2 / 4 / 8 = 原速的 1/2、1/4、1/8 |
| `#stag` `#smod` | 慢放计时器与取余（`#smod = #stag % #slowdiv`） |
| `#tick` | HUD 刷新计数器（0–4） |
| `#boot` | 首帧初始化标记 |

---

## 七、已知限制

- **HUD 用 actionbar**：会被其他 actionbar 消息（对话、提示）临时覆盖，0.25 秒内自动恢复。
- **所有玩家共享同一个 HUD 布局**：布局是全局设置，不是每人各自的。若需要「每人自选」，要把 `#ord/#showd/#showt/#shows`
  改成玩家计分板（模板未内置）。
- **变速期间睡觉不跳夜**：见第四节。
- **`#day` 是「真实天数 + 偏移」**：真实天数绑在 gametime 上（`time set` 改时刻不影响它），要改显示天数请用 `clock:day/*`（见 2.4）。
