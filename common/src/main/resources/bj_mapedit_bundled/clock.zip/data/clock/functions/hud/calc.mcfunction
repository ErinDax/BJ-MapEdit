# ============================================================
#  clock:hud/calc —— 计算时间数值（纯算术，不负责绘制）
#  供 hud/layout、hud/draw 与 status 复用。
# ============================================================

# ── 读当前时刻（0 = 06:00，24000 tick 一天）──
execute store result score #t clock.data run time query daytime

# ── 小时 = (tick / 1000 + 6) % 24 ──
scoreboard players operation #h clock.data = #t clock.data
scoreboard players operation #h clock.data /= #1000 clock.data
scoreboard players operation #h clock.data += #6 clock.data
scoreboard players operation #h clock.data %= #24 clock.data

# ── 分钟 = (tick % 1000) * 60 / 1000 ──
scoreboard players operation #m clock.data = #t clock.data
scoreboard players operation #m clock.data %= #1000 clock.data
scoreboard players operation #m clock.data *= #60 clock.data
scoreboard players operation #m clock.data /= #1000 clock.data

# ── 拆十位 / 个位（用于显示前导零，如 06:05）──
scoreboard players operation #h10 clock.data = #h clock.data
scoreboard players operation #h10 clock.data /= #10 clock.data
scoreboard players operation #h1 clock.data = #h clock.data
scoreboard players operation #h1 clock.data %= #10 clock.data
scoreboard players operation #m10 clock.data = #m clock.data
scoreboard players operation #m10 clock.data /= #10 clock.data
scoreboard players operation #m1 clock.data = #m clock.data
scoreboard players operation #m1 clock.data %= #10 clock.data

# ── 真实世界天数 = gametime / 24000 + 1 ──
execute store result score #dayraw clock.data run time query gametime
scoreboard players operation #dayraw clock.data /= #24000 clock.data
scoreboard players operation #dayraw clock.data += #1 clock.data

# ── 显示天数 = 真实天数 + 偏移 #dayoff（由 clock:day/* 调整）──
scoreboard players operation #day clock.data = #dayraw clock.data
scoreboard players operation #day clock.data += #dayoff clock.data
