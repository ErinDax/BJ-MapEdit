# 把显示天数设为第 3 天（不影响真实世界年龄）
function clock:hud/calc
scoreboard players set #dayoff clock.data 3
scoreboard players operation #dayoff clock.data -= #dayraw clock.data
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"天数已设为第 3 天","color":"gray"}]
