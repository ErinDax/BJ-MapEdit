# 布局 9：第N天 + 时段

execute if score #h clock.data matches 0..2 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"},{"text":"  "},{"text":"深夜","color":"dark_blue"}]
execute if score #h clock.data matches 3..5 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"},{"text":"  "},{"text":"凌晨","color":"aqua"}]
execute if score #h clock.data matches 6..8 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"},{"text":"  "},{"text":"清晨","color":"yellow"}]
execute if score #h clock.data matches 9..11 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"},{"text":"  "},{"text":"上午","color":"gold"}]
execute if score #h clock.data matches 12..14 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"},{"text":"  "},{"text":"正午","color":"white"}]
execute if score #h clock.data matches 15..17 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"},{"text":"  "},{"text":"下午","color":"gold"}]
execute if score #h clock.data matches 18..20 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"},{"text":"  "},{"text":"黄昏","color":"red"}]
execute if score #h clock.data matches 21..23 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"},{"text":"  "},{"text":"夜晚","color":"blue"}]
