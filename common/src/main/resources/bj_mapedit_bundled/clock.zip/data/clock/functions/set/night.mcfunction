# 跳到 21:00 夜晚（daytime 15000）
time set 15000
function clock:hud/update
