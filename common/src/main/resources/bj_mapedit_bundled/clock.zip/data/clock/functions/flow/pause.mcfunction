# 冻结时间：昼夜停止流动（玩家与世界都停在当前时刻）
gamerule doDaylightCycle false
scoreboard players set #speed clock.data 0
scoreboard players set #slowdiv clock.data 1
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"时间流逝已暂停","color":"gray"}]
