# 跳到 12:00 正午（daytime 6000）
time set 6000
function clock:hud/update
