# 跳到 06:00 清晨（daytime 0）
time set 0
function clock:hud/update
