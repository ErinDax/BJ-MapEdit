# 跳到 09:00 上午（daytime 3000）
time set 3000
function clock:hud/update
