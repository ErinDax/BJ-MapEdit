# 隐藏「时间」
scoreboard players set #showt clock.data 0
function clock:hud/layout
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"已隐藏「时间」","color":"gray"}]
