# 布局 15：时段

execute if score #h clock.data matches 0..2 run title @a[tag=clock.on] actionbar [{"text":"深夜","color":"dark_blue"}]
execute if score #h clock.data matches 3..5 run title @a[tag=clock.on] actionbar [{"text":"凌晨","color":"aqua"}]
execute if score #h clock.data matches 6..8 run title @a[tag=clock.on] actionbar [{"text":"清晨","color":"yellow"}]
execute if score #h clock.data matches 9..11 run title @a[tag=clock.on] actionbar [{"text":"上午","color":"gold"}]
execute if score #h clock.data matches 12..14 run title @a[tag=clock.on] actionbar [{"text":"正午","color":"white"}]
execute if score #h clock.data matches 15..17 run title @a[tag=clock.on] actionbar [{"text":"下午","color":"gold"}]
execute if score #h clock.data matches 18..20 run title @a[tag=clock.on] actionbar [{"text":"黄昏","color":"red"}]
execute if score #h clock.data matches 21..23 run title @a[tag=clock.on] actionbar [{"text":"夜晚","color":"blue"}]
