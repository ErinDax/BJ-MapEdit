# 布局 13：第N天

execute if score #h clock.data matches 0..2 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"}]
execute if score #h clock.data matches 3..5 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"}]
execute if score #h clock.data matches 6..8 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"}]
execute if score #h clock.data matches 9..11 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"}]
execute if score #h clock.data matches 12..14 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"}]
execute if score #h clock.data matches 15..17 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"}]
execute if score #h clock.data matches 18..20 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"}]
execute if score #h clock.data matches 21..23 run title @a[tag=clock.on] actionbar [{"text":"第"},{"score":{"name":"#day","objective":"clock.data"},"color":"gray"},{"text":"天"}]
