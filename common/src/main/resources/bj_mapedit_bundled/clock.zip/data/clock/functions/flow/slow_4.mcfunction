# 0.25 倍速（原速的 1/4）：关掉原版推进，每 4 tick 只推进 1 tick
gamerule doDaylightCycle false
scoreboard players set #speed clock.data 1
scoreboard players set #slowdiv clock.data 4
scoreboard players set #stag clock.data 0
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"时间流逝 0.25 倍速（原速的 1/4）","color":"gray"}]
