# 显示排序 1：第N天 → 时:分 → 时段（三元素全显时生效）
scoreboard players set #ord clock.data 1
function clock:hud/layout
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"排序已切换：第N天 → 时:分 → 时段","color":"gray"}]
