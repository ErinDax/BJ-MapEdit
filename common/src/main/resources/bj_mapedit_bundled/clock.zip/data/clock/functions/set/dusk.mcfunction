# 跳到 18:00 黄昏（daytime 12000）
time set 12000
function clock:hud/update
