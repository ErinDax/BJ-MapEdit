# ============================================================
#  clock:hud/update —— 刷新一次 HUD（算数值 → 算布局 → 绘制）
#  也可 /function clock:hud/update 手动立即刷新
# ============================================================
function clock:hud/calc
function clock:hud/layout
function clock:hud/draw
