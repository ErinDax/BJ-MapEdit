# ============================================================
#  clock:hud/layout —— 由「排序 #ord + 三个显隐开关」算出布局号 1–15
#  布局号含义见 /function clock:cfg/help
#  默认：ord=1、三元素全显 → 布局 1（第N天 时:分 时段）
# ============================================================

# 基准：三元素全显时，布局号 = 排序号
scoreboard players operation #layout clock.data = #ord clock.data

# 可见元素个数
scoreboard players operation #cnt clock.data = #showd clock.data
scoreboard players operation #cnt clock.data += #showt clock.data
scoreboard players operation #cnt clock.data += #shows clock.data

# ── 只剩 1 个元素：13 天数 / 14 时间 / 15 时段 ──
execute if score #cnt clock.data matches 1 if score #showd clock.data matches 1 run scoreboard players set #layout clock.data 13
execute if score #cnt clock.data matches 1 if score #showt clock.data matches 1 run scoreboard players set #layout clock.data 14
execute if score #cnt clock.data matches 1 if score #shows clock.data matches 1 run scoreboard players set #layout clock.data 15

# ── 剩 2 个元素：天数 + 时间 → 7 / 8 ──
execute if score #cnt clock.data matches 2 if score #showd clock.data matches 1 if score #showt clock.data matches 1 run scoreboard players set #layout clock.data 7
execute if score #cnt clock.data matches 2 if score #showd clock.data matches 1 if score #showt clock.data matches 1 if score #ord clock.data matches 3..4 run scoreboard players set #layout clock.data 8
execute if score #cnt clock.data matches 2 if score #showd clock.data matches 1 if score #showt clock.data matches 1 if score #ord clock.data matches 6 run scoreboard players set #layout clock.data 8

# ── 剩 2 个元素：天数 + 时段 → 9 / 10 ──
execute if score #cnt clock.data matches 2 if score #showd clock.data matches 1 if score #shows clock.data matches 1 run scoreboard players set #layout clock.data 9
execute if score #cnt clock.data matches 2 if score #showd clock.data matches 1 if score #shows clock.data matches 1 if score #ord clock.data matches 4..6 run scoreboard players set #layout clock.data 10

# ── 剩 2 个元素：时间 + 时段 → 11 / 12 ──
execute if score #cnt clock.data matches 2 if score #showt clock.data matches 1 if score #shows clock.data matches 1 run scoreboard players set #layout clock.data 11
execute if score #cnt clock.data matches 2 if score #showt clock.data matches 1 if score #shows clock.data matches 1 if score #ord clock.data matches 2 run scoreboard players set #layout clock.data 12
execute if score #cnt clock.data matches 2 if score #showt clock.data matches 1 if score #shows clock.data matches 1 if score #ord clock.data matches 5..6 run scoreboard players set #layout clock.data 12
