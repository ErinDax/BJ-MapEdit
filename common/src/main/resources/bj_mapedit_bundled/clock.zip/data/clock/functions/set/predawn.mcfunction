# 跳到 03:00 凌晨（daytime 21000）
time set 21000
function clock:hud/update
