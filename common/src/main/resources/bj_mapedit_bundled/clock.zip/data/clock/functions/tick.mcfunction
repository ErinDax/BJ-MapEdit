# ============================================================
#  clock:tick —— 每 tick 执行
# ============================================================

# ── 首次启动初始化（一次）──
execute if score #boot clock.data matches 0 run function clock:boot

# ── 新玩家默认开启 HUD ──
execute as @a[tag=!clock.on,tag=!clock.off] run tag @s add clock.on

# ── 玩家自助开关：/trigger clock.hud set 1（开） / set 2（关）──
execute as @a[scores={clock.hud=1}] run tag @s add clock.on
execute as @a[scores={clock.hud=1}] run tag @s remove clock.off
execute as @a[scores={clock.hud=1}] run scoreboard players reset @s clock.hud
execute as @a[scores={clock.hud=2}] run tag @s add clock.off
execute as @a[scores={clock.hud=2}] run tag @s remove clock.on
execute as @a[scores={clock.hud=2}] run scoreboard players reset @s clock.hud

# ── HUD 刷新：每 5 tick（0.25 秒）一次 ──
execute if score #tick clock.data matches 0 if entity @a[tag=clock.on] run function clock:hud/update
scoreboard players add #tick clock.data 1
execute if score #tick clock.data matches 5.. run scoreboard players set #tick clock.data 0

# ── 时间流逝（倍速模式：flow/run 内部按 #speed 分支，1 = 原生不干预）──
function clock:flow/run
