# 2 倍速流逝（关掉原版昼夜循环，由数据包自己推进时间）
gamerule doDaylightCycle false
scoreboard players set #speed clock.data 2
scoreboard players set #slowdiv clock.data 1
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"时间流逝 2 倍速","color":"gray"}]
