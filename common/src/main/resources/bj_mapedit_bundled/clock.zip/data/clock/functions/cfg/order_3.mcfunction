# 显示排序 3：时:分 → 第N天 → 时段（三元素全显时生效）
scoreboard players set #ord clock.data 3
function clock:hud/layout
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"排序已切换：时:分 → 第N天 → 时段","color":"gray"}]
