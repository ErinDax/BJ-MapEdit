# ============================================================
#  clock:init —— 数据包加载时执行（load 标签）
#  只做「不依赖世界」的事：建计分板 + 写常量。
#  世界相关操作（gamerule / tag 玩家）放到 clock:boot，由 tick 首帧触发。
# ============================================================

# ── 计分板 ──
scoreboard objectives add clock.data dummy
scoreboard objectives add clock.hud trigger

# ── 常量（假玩家）──
scoreboard players set #0 clock.data 0
scoreboard players set #1 clock.data 1
scoreboard players set #6 clock.data 6
scoreboard players set #10 clock.data 10
scoreboard players set #24 clock.data 24
scoreboard players set #60 clock.data 60
scoreboard players set #100 clock.data 100
scoreboard players set #1000 clock.data 1000
scoreboard players set #24000 clock.data 24000

# ── 运行状态 ──
scoreboard players set #tick clock.data 0
scoreboard players set #speed clock.data 1
scoreboard players set #boot clock.data 0
scoreboard players set #slowdiv clock.data 1
scoreboard players set #stag clock.data 0
scoreboard players set #smod clock.data 0

# ── 显示布局（默认：第N天  时:分  时段）──
scoreboard players set #ord clock.data 1
scoreboard players set #showd clock.data 1
scoreboard players set #showt clock.data 1
scoreboard players set #shows clock.data 1
scoreboard players set #cnt clock.data 0
scoreboard players set #layout clock.data 1

# ── 天数偏移（#day 显示值 = 真实世界天数 + #dayoff）──
#  想「从第 7 天开始」：/function clock:day/set_7
#  想任意天数：  /scoreboard players set #daytar clock.data 37 → /function clock:day/to
scoreboard players set #dayoff clock.data 0
scoreboard players set #daytar clock.data 1

# ── 初始化：显示值归零（首帧会被 calc 重算）──
scoreboard players set #t clock.data 0
scoreboard players set #h clock.data 0
scoreboard players set #m clock.data 0
scoreboard players set #h10 clock.data 0
scoreboard players set #h1 clock.data 0
scoreboard players set #m10 clock.data 0
scoreboard players set #m1 clock.data 0
scoreboard players set #dayraw clock.data 1
scoreboard players set #day clock.data 1
