# ============================================================
#  clock:nextday —— 直接跳到次日 06:00（剧情/轮回地图常用）
#  用法：/function clock:nextday
# ============================================================
time set 0
scoreboard players add #dayoff clock.data 1
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"已跳转到次日 06:00（天数 +1）","color":"gray"}]
