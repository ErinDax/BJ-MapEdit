# ============================================================
#  clock:status —— 向执行者报告当前时间与流逝状态
#  用法：/function clock:status
# ============================================================
function clock:hud/calc
tellraw @s [{"text":"[时钟] ","color":"gold"},{"score":{"name":"#h10","objective":"clock.data"}},{"score":{"name":"#h1","objective":"clock.data"}},{"text":":"},{"score":{"name":"#m10","objective":"clock.data"}},{"score":{"name":"#m1","objective":"clock.data"}},{"text":"  第"},{"score":{"name":"#day","objective":"clock.data"}},{"text":"天   流逝速度 "},{"score":{"name":"#speed","objective":"clock.data"},"color":"aqua"},{"text":"  （0=冻结 / 1=原生 / 2·4·8=倍速）","color":"gray"}]
execute if score #slowdiv clock.data matches 2.. run tellraw @s [{"text":"[时钟] ","color":"gold"},{"text":"当前为慢速：原速的 1/"},{"score":{"name":"#slowdiv","objective":"clock.data"},"color":"aqua"},{"text":"（每 "},{"score":{"name":"#slowdiv","objective":"clock.data"},"color":"aqua"},{"text":" tick 推进 1 tick）","color":"gray"}]
