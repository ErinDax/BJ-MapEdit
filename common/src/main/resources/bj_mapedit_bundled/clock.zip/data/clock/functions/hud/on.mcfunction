# ============================================================
#  clock:hud/on —— 给所有在线玩家开启时钟 HUD
#  用法：/function clock:hud/on
# ============================================================
tag @a add clock.on
tag @a remove clock.off
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"已开启时间显示","color":"gray"}]
