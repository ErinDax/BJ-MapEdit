# 显示天数 +1（剧情推进一天，不动真实时间）
function clock:hud/calc
scoreboard players add #dayoff clock.data 1
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"天数 +1","color":"gray"}]
