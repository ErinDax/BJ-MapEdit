# 隐藏「天数」
scoreboard players set #showd clock.data 0
function clock:hud/layout
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"已隐藏「天数」","color":"gray"}]
