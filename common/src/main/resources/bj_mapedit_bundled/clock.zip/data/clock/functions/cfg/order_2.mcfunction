# 显示排序 2：第N天 → 时段 → 时:分（三元素全显时生效）
scoreboard players set #ord clock.data 2
function clock:hud/layout
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"排序已切换：第N天 → 时段 → 时:分","color":"gray"}]
