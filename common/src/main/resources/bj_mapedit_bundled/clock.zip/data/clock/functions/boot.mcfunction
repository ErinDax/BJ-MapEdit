# ============================================================
#  clock:boot —— 世界加载后的首次初始化（由 clock:tick 守卫触发一次）
#  放在这里是因为 load 阶段跑 gamerule 等世界命令可能静默失败。
# ============================================================

# ── 基线：原生时间流逝开启 ──
# 若你的地图需要「时间静止开局」，把下面这行改成 false（或用 /function clock:flow/pause）
gamerule doDaylightCycle true
scoreboard players set #speed clock.data 1

# ── 在线玩家默认开启 HUD（已被手动关闭 tag=clock.off 的不动）──
tag @a[tag=!clock.off] add clock.on

# ── 标记已完成 ──
scoreboard players set #boot clock.data 1
