# ============================================================
#  clock:flow/run —— 由 clock:tick 每 tick 调用
#  #speed ：0 冻结 / 1 原生或慢速 / 2·4·8 加速
#  #slowdiv：1 不慢放；2 / 4 / 8 = 原速的 1/2、1/4、1/8
# ============================================================

# ── 加速：#speed ≥ 2 时每 tick 补 time ──
execute if score #speed clock.data matches 2 run time add 2
execute if score #speed clock.data matches 4 run time add 4
execute if score #speed clock.data matches 8 run time add 8

# ── 慢速：#speed = 1 且 #slowdiv ≥ 2 时，每 #slowdiv tick 才推进 1 tick ──
scoreboard players add #stag clock.data 1
scoreboard players operation #smod clock.data = #stag clock.data
scoreboard players operation #smod clock.data %= #slowdiv clock.data
execute if score #speed clock.data matches 1 if score #slowdiv clock.data matches 2.. if score #smod clock.data matches 0 run time add 1
