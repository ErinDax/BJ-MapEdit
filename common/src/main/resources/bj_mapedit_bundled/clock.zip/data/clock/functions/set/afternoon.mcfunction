# 跳到 15:00 下午（daytime 9000）
time set 9000
function clock:hud/update
