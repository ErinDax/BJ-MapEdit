# 显示天数 -1
function clock:hud/calc
scoreboard players remove #dayoff clock.data 1
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"天数 -1","color":"gray"}]
