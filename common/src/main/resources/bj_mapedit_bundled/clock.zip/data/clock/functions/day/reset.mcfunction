# 清除天数偏移，回到真实世界天数
scoreboard players set #dayoff clock.data 0
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"已回到真实世界天数","color":"gray"}]
