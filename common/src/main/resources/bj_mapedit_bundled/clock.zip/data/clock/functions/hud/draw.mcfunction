# ============================================================
#  clock:hud/draw —— 按布局号分发（布局号 1–15，见 /function clock:cfg/help）
#  实际绘制在 clock:hud/draw/l01 … l15
# ============================================================

execute if score #layout clock.data matches 1 run function clock:hud/draw/l01
execute if score #layout clock.data matches 2 run function clock:hud/draw/l02
execute if score #layout clock.data matches 3 run function clock:hud/draw/l03
execute if score #layout clock.data matches 4 run function clock:hud/draw/l04
execute if score #layout clock.data matches 5 run function clock:hud/draw/l05
execute if score #layout clock.data matches 6 run function clock:hud/draw/l06
execute if score #layout clock.data matches 7 run function clock:hud/draw/l07
execute if score #layout clock.data matches 8 run function clock:hud/draw/l08
execute if score #layout clock.data matches 9 run function clock:hud/draw/l09
execute if score #layout clock.data matches 10 run function clock:hud/draw/l10
execute if score #layout clock.data matches 11 run function clock:hud/draw/l11
execute if score #layout clock.data matches 12 run function clock:hud/draw/l12
execute if score #layout clock.data matches 13 run function clock:hud/draw/l13
execute if score #layout clock.data matches 14 run function clock:hud/draw/l14
execute if score #layout clock.data matches 15 run function clock:hud/draw/l15
