# 显示排序 4：时:分 → 时段 → 第N天（三元素全显时生效）
scoreboard players set #ord clock.data 4
function clock:hud/layout
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"排序已切换：时:分 → 时段 → 第N天","color":"gray"}]
