# 把显示天数设为「#daytar」里的任意值
# 用法：/scoreboard players set #daytar clock.data 37  →  /function clock:day/to
function clock:hud/calc
scoreboard players operation #dayoff clock.data = #daytar clock.data
scoreboard players operation #dayoff clock.data -= #dayraw clock.data
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"天数已设为第 "},{"score":{"name":"#daytar","objective":"clock.data"},"color":"aqua"},{"text":" 天","color":"gray"}]
