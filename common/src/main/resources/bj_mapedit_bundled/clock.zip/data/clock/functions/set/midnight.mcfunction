# 跳到 00:00 午夜（daytime 18000）
time set 18000
function clock:hud/update
