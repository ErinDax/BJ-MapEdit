# ============================================================
#  clock:hud/off —— 关闭时钟 HUD（actionbar 会自然消失）
#  用法：/function clock:hud/off
# ============================================================
tag @a remove clock.on
tag @a add clock.off
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"已关闭时间显示（/trigger clock.hud set 1 可自开）","color":"gray"}]
