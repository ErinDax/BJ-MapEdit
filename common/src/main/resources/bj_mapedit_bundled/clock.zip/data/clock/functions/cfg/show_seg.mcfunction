# 显示「时段」
scoreboard players set #shows clock.data 1
function clock:hud/layout
function clock:hud/update
tellraw @a [{"text":"[时钟] ","color":"gold"},{"text":"已显示「时段」","color":"gray"}]
